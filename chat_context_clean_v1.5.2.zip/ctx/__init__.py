"""Local semantic chat notebook."""
