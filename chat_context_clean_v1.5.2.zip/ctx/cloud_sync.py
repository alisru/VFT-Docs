"""
Background debounced cloud sync worker for Canvases:
1. Git: commits and pushes chat_context/canvases/ to configured remote/branch.
2. Google Drive: copies chat_context/canvases/ to configured rclone remote as native Google Docs.
Settings are loaded dynamically from config.json via ctx.config.
"""
import re
import subprocess
import threading
import time
from pathlib import Path

from .config import get_git_config, get_gdrive_config
from .db import CANVASES_DIR, ROOT

SYNC_DELAY = 30  # seconds to wait after last canvas edit before pushing
GDOCS_STAGING_DIR = ROOT / "drawing_board" / "gdocs_staging"


def prepare_gdocs_staging():
    """Converts updated .md canvases into clean .docx files for Google Docs import."""
    GDOCS_STAGING_DIR.mkdir(parents=True, exist_ok=True)
    for md_file in CANVASES_DIR.rglob("*.md"):
        rel = md_file.relative_to(CANVASES_DIR)
        docx_file = GDOCS_STAGING_DIR / rel.parent / (rel.stem + ".docx")
        if docx_file.exists() and docx_file.stat().st_mtime >= md_file.stat().st_mtime:
            continue
        docx_file.parent.mkdir(parents=True, exist_ok=True)
        raw_text = md_file.read_text(encoding="utf-8", errors="replace")
        clean_text = re.sub(r"^---\n.*?\n---\n+", "", raw_text, flags=re.S)
        try:
            p = subprocess.Popen(
                ["pandoc", "-f", "markdown", "-t", "docx", "-o", str(docx_file)],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
            )
            p.communicate(input=clean_text, timeout=20)
        except FileNotFoundError:
            print("[canvas-sync] Note: 'pandoc' not found on system PATH. Install pandoc for native Google Docs conversion.", flush=True)
            break
        except Exception as err:
            print(f"[canvas-sync] Pandoc conversion error for {md_file.name}: {err}", flush=True)


class CanvasCloudSync:
    def __init__(self):
        self._timer = None
        self._lock = threading.Lock()
        self._changed_titles = set()
        self._is_syncing = False
        self.last_sync_time = None
        self.last_sync_status = "idle"

    def notify_change(self, canvas_title: str):
        """Called whenever a canvas file is written or updated on disk."""
        with self._lock:
            self._changed_titles.add(canvas_title)
            if self._timer:
                self._timer.cancel()
            self._timer = threading.Timer(SYNC_DELAY, self._on_timer)
            self._timer.daemon = True
            self._timer.start()
            print(f"[canvas-sync] Scheduled auto-sync in {SYNC_DELAY}s for '{canvas_title}'", flush=True)

    def trigger_immediate(self):
        """Triggers an immediate sync, cancelling any pending debounced timer."""
        with self._lock:
            if self._timer:
                self._timer.cancel()
                self._timer = None
            titles = list(self._changed_titles)
            self._changed_titles.clear()

        threading.Thread(target=self._run_sync, args=(titles,), daemon=True).start()

    def _on_timer(self):
        with self._lock:
            titles = list(self._changed_titles)
            self._changed_titles.clear()
            self._timer = None

        threading.Thread(target=self._run_sync, args=(titles,), daemon=True).start()

    def _run_sync(self, titles):
        if self._is_syncing:
            print("[canvas-sync] Sync already in progress, skipping overlapping run", flush=True)
            return

        self._is_syncing = True
        self.last_sync_status = "syncing"
        print(f"[canvas-sync] Starting sync for: {titles or 'all canvases'}", flush=True)

        git_cfg = get_git_config()
        gdrive_cfg = get_gdrive_config()

        git_ok = True
        gdrive_ok = True

        # --- 1. Git Auto-Commit and Push ---
        if git_cfg.get("enabled", False):
            git_remote = git_cfg.get("remote", "origin")
            git_branch = git_cfg.get("branch", "main")
            if not (CANVASES_DIR / ".git").exists():
                print("[canvas-sync] Git sync is enabled, but canvases/ is not a git repo. Run 'python setup_sync.py' to initialize.", flush=True)
                git_ok = False
            else:
                try:
                    status_res = subprocess.run(
                        ["git", "status", "--porcelain"],
                        cwd=CANVASES_DIR,
                        capture_output=True,
                        text=True,
                        timeout=15,
                    )
                    has_changes = bool(status_res.stdout.strip())
                    if has_changes:
                        subprocess.run(
                            ["git", "add", "."],
                            cwd=CANVASES_DIR,
                            check=True,
                            timeout=15,
                        )
                        if titles:
                            title_summary = titles[0] if len(titles) == 1 else f"{len(titles)} canvases ({', '.join(titles[:2])})"
                            commit_msg = f"auto(canvas): update {title_summary}"
                        else:
                            commit_msg = "auto(canvas): sync canvases"

                        commit_res = subprocess.run(
                            ["git", "commit", "-m", commit_msg],
                            cwd=CANVASES_DIR,
                            capture_output=True,
                            text=True,
                            timeout=20,
                        )
                        if commit_res.returncode == 0:
                            print(f"[canvas-sync] Git committed: {commit_msg}", flush=True)
                            push_res = subprocess.run(
                                ["git", "push", git_remote, git_branch],
                                cwd=CANVASES_DIR,
                                capture_output=True,
                                text=True,
                                timeout=45,
                            )
                            if push_res.returncode == 0:
                                print(f"[canvas-sync] Git pushed to {git_remote}/{git_branch} successfully", flush=True)
                                git_ok = True
                            else:
                                print(f"[canvas-sync] Git push failed: {push_res.stderr.strip()}", flush=True)
                                git_ok = False
                        else:
                            print(f"[canvas-sync] Git commit note: {commit_res.stdout.strip() or commit_res.stderr.strip()}", flush=True)
                    else:
                        print(f"[canvas-sync] Git: working tree clean for {git_remote}/{git_branch}, nothing to commit", flush=True)
                        git_ok = True
                except FileNotFoundError:
                    print("[canvas-sync] Git CLI not found on system PATH. Install git or run 'python setup_sync.py'.", flush=True)
                    git_ok = False
                except Exception as e:
                    print(f"[canvas-sync] Git error: {e}", flush=True)
                    git_ok = False
        else:
            print("[canvas-sync] Git sync is disabled in config.json. Skipping.", flush=True)

        # --- 2. Google Drive Sync as Native Google Docs ---
        if gdrive_cfg.get("enabled", False):
            if CANVASES_DIR.exists():
                rclone_remote = gdrive_cfg.get("rclone_remote", "gdrive").strip(":")
                folder_name = gdrive_cfg.get("folder_name", "Canvases").strip("/")
                target_dest = f"{rclone_remote}:{folder_name}"
                root_folder_id = gdrive_cfg.get("root_folder_id", "").strip()

                prepare_gdocs_staging()
                cmd = [
                    "rclone",
                    "copy",
                    str(GDOCS_STAGING_DIR),
                    target_dest,
                    "--drive-import-formats",
                    "docx",
                    "--drive-allow-import-name-change",
                    "--tpslimit",
                    "3",
                    "--contimeout",
                    "15s",
                    "--timeout",
                    "90s",
                ]
                if root_folder_id:
                    cmd.extend(["--drive-root-folder-id", root_folder_id])

                try:
                    rclone_res = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=300,
                    )
                    if rclone_res.returncode == 0:
                        print(f"[canvas-sync] Google Drive: canvases synced successfully as native Google Docs to '{target_dest}'", flush=True)
                        gdrive_ok = True
                    else:
                        print(f"[canvas-sync] Google Drive sync error: {rclone_res.stderr.strip()}", flush=True)
                        gdrive_ok = False
                except FileNotFoundError:
                    print("[canvas-sync] 'rclone' executable not found on system PATH. Install rclone to enable Google Drive sync.", flush=True)
                    gdrive_ok = False
                except Exception as e:
                    print(f"[canvas-sync] Google Drive error: {e}", flush=True)
                    gdrive_ok = False
        else:
            print("[canvas-sync] Google Drive sync is disabled in config.json. Skipping.", flush=True)

        self._is_syncing = False
        self.last_sync_time = time.time()
        self.last_sync_status = "ok" if (git_ok and gdrive_ok) else "partial_or_error"


cloud_sync = CanvasCloudSync()
